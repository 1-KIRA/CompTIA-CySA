## Episode Name: How do we Document & Train for Risk?


### Objectives:

At the end of this episode, I will be able to:

Identify what compensating controls are, and why we would want to deploy them to
help create a defense-in-depth architecture within an organization.

Identify what a tabletop exercise is, and what the importance of it is to an
organization's ability to understand and manage risk.

Identify what a penetration test is, and what the importance of it is to an
organization's ability to understand and manage risk.

Identify what Red, Blue and White Team exercises are, and what the importance of
them is to an organization's ability to understand and manage risk.


### External Resources:

How do we Document & Train for Risk?

Documented Compensating Controls -

The idea of compensating controls was introduced by PCI DSS. Under that standard,
a compensating control is one that is used because of an overriding business or
technological reason for not deploying the control recommended by the standard.

A compensating control therefore is one that serves the same purpose as the
recommended control and affords the same (or better) level of protection but uses
a different methodology or technology.

An assessor must approve the deployment of the control. This will require
documentation to show that the compensating control is deployed as part of the
process, is applied consistently by employees, and is monitored for effectiveness.

Part of the risk management framework is ongoing monitoring to detect new sources
of risk or changed risk probabilities or impacts.

NOTE: Security controls will, of course, be tested by actual events, but it is
best to be proactive and initiate training and exercises that test system security.


Tabletop Exercises -

A tabletop exercise is a facilitator-led training event where staff practice
responses to a particular risk scenario.

The facilitator's role is to describe the scenario as it starts and unfolds, and
to prompt participants for their responses.

NOTE: As well as a facilitator and the participants, there may be other
observers and evaluators who witness and record the exercise and assist with
follow-up analysis. A single event may use multiple scenarios, but it is
important to use practical and realistic examples, and to focus on each
scenario in turn.

These are simple to set up but do not provide any practical evidence of things
that could go wrong, time to complete, and so on.


Penetration Testing -

A key part of cybersecurity analysis is to actively test the selection and
configuration of security controls by trying to break through them in a
penetration test (or pen test).

When performing penetration testing, there needs to be a well-defined scope
setting out the system under assessment and limits to testing, plus a clear
methodology and rules of engagement.

There are many models and best practice guides for conducting penetration tests.
A good starting point is NIST's Technical Guide to Information Security Testing
and Assessment (SP 800-115).

SP 800-115 lists three principal activities within an assessment:

	• Testing the object under assessment to discover vulnerabilities or to prove
  the effectiveness of security controls.

	• Examining assessment objects to understand the security system and identify
  any logical weaknesses. This might highlight a lack of security controls or a
  common misconfiguration.

	• Interviewing personnel to gather information and probe attitudes toward and
  understanding of security.


The first step in planning a pen test (pre-engagement) will be to determine the
scope of the assessment and a methodology, then put in place the resources to
carry it out (qualified staff, tools, budget, and so on).

﻿NOTE: It is often helpful to use third parties to perform pen tests, or at least
for assessments to be performed by people other than those who set up the
security system.

This is the best means of finding vulnerabilities that may have been overlooked
by the security team. The drawback of using a third party is the level of trust
that must be invested in them; the drawback of using internal staff is that they
might not have the knowledge and skills typical of criminal hackers.


Red and Blue (and White) Team Exercises -

Penetration testing can form the basis of functional exercises. One of the
best-established means of testing a security system for weaknesses is to play
"war game" exercises in which the security personnel split into teams:

	• Red team — This team acts as the adversary, attempting to penetrate the
  network or exploit the network as a rogue internal attacker. The red
  (or "tiger") team might be selected members of in-house security staff or
  might be a third-party company or consultant contracted to perform the role.

	• Blue team — This team operates the security system with a view to detecting
  and repelling the red team.

	• White team — This team sets the parameters for the exercise and is
  authorized to call a halt if the exercise gets out of hand or should no
  longer be continued for business reasons.

The white team will determine objectives and success/fail criteria for the red
and blue teams.

The white team will also take responsibility for reporting the outcomes of the
exercises, diagnosing lessons learned, and making recommendations for
improvements to security controls.

NOTE: War gaming may be used for training purposes for new staff hires, for
instance, or when introducing new security systems and software.
