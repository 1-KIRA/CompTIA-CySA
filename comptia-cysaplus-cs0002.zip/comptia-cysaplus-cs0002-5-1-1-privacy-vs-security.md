## Episode Name: Privacy vs. Security


### Objectives:

At the end of this episode, I will be able to:

Identify what the key aspects of privacy are.

Identify the legal requirements associated with privacy.

Understand why privacy and security must both be elements of a holistic approach
to safeguarding data in the organization.


### External Resources:

Privacy vs. Security

All data, including public information, must be kept securely within a
processing/storage system with the attributes of confidentiality, integrity,
and availability.

NOTE: As distinct from this security requirement, you also need to consider the
impact of privacy in shaping data governance.

Any type of information or asset can be thought of in terms of how a compromise
of that information can threaten the three core security attributes of the
confidentiality, integrity, and availability (CIA) triad.

When surveying information within an organization, it is important not to solely
judge the type of information, but how that information is used throughout the
business as well.


Privacy versus Security -
﻿
Privacy is a data governance requirement that arises when collecting and
processing personal data.

Personal data is any information about an identifiable individual person,
referred to as the data subject.

Where data security controls focus on the CIA attributes of the processing
system, privacy requires policies to identify private data, ensure that storage,
processing, and retention is compliant with relevant regulations, limit access
to the private data to authorized persons only, and ensure the rights of data
subjects to review and remove any information held about them are met.


Legal Requirements -

Data owners should be aware of any legal or regulatory issues with the data.
The right to privacy, as enacted by regulations such as the EU's General Data
Protection Regulation (GDPR), means that personal data cannot be collected,
processed, or retained without the individual's informed consent.

Informed consent means that the data must be collected and processed only for
the stated purpose, and that purpose must be clearly described to the user in
plain language, not legalese. The GDPR gives data subjects rights to withdraw
consent, and to inspect, amend, or erase data held about them.

Where data security is compromised, data privacy regulations mean that the data
subject must be informed about the data breach. Under GDPR, the timescale for
breach notification is strict—typically within 72 hours.

As well as the data subject, it may also be necessary to notify a regulator. A
data breach can mean the loss or theft of information, the accidental disclosure
of information, or the loss of damage of information.

NOTE: there are substantial risks from accidental breaches if effective
procedures are not in-place. If a database administrator can run a query that
shows unredacted credit card numbers, that is a data breach, regardless of
whether the query ever leaves the database server.


GDPR offers stronger protections than most federal and state laws in the US,
which tend to focus on industry-specific regulations, narrower definitions of
personal data, and fewer rights and protections for data subjects. The passage
of the California Consumer Privacy Act (CCPA) changes the picture for domestic
US legislation, however.

The following list summarizes major US federal privacy-related standards or laws
other than GDPR and the CCPA that may be applicable to your enterprise:

	• The Sarbanes-Oxley Act (SOX) — dictates requirements for the storage and
  retention of documents relating to an organization's financial and business
  operations, including the type of documents to be stored and their retention
  periods. It is relevant for any publicly traded company with a market value of
  at least $75 million.

	• The Gramm-Leach-Bliley Act (GLBA) — institutes requirements that help
  protect the privacy of an individual's financial information that is held by
  financial institutions and others, such as tax preparation companies. The
  privacy standards and rules created as part of GLBA safeguard private
  information and set penalties in the event of a violation. GLBA also requires
  a coherent risk management and information security process.

	• The Federal Information Security Management Act (FISMA) — requires federal
  organizations to adopt information assurance controls. It mandates the
  documentation of system information, the use of risk assessment, the use of
  security controls, and the adoption of continuous monitoring.

	• The Committee of Sponsoring Organizations of the Treadway
  Commission (COSO) — provides guidance on a variety of governance-related
  topics including fraud, controls, finance, and ethics. COSO's ERM-integrated
  framework defines risk and related common terminology, lists key components of
  risk management strategies, and supplies direction and criteria for enhancing
  risk management practices.

	• The Health Insurance Portability and Accountability Act (HIPAA) — establishes
  several rules and regulations regarding healthcare in the United States. With
  the rise of electronic medical records, HIPAA standards have been implemented
  to protect the privacy of patient medical information through restricted
  access to medical records and regulations for sharing medical records.
