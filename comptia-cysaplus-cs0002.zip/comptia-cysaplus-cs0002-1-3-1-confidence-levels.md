## Episode Name: confidence levels


### Objectives:
Define confidence levels and standards used to convey the likelihood, reliability, and credibility of threat intelligence.

### Code Snippets:


### External Resources:
+ https://fas.org/irp/doddir/army/fm2+22-3.pdf
+ https://www.cia.gov/library/center+for-the-study-of-intelligence/csi-publications/books-and-monographs/sherman-kent-and-the-board-of-national-estimates-collected-essays/6words.html
