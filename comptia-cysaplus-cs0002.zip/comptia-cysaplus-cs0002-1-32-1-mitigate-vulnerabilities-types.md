## Episode Name: mitigate vulnerabilities types


### Objectives:
Identify a variety of common attack types like Insecure Object Reference, race conditions, and insecure component use as well as their associated mitigation techniques.

### Code Snippets:


### External Resources:
+ https://lightningsecurity.io/blog/race+conditions/
+ https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html
