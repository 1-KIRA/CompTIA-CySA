## Episode Name: Policies and Procedures


### Objectives:

At the end of this episode, I will be able to:

Identify what a Digital Forensics Analyst is.

Identify what the proper order for the four Digital Forensics Procedures is.

Identify what the concept of work product retention is, and understand why it is
an important factor governing how a forensic analyst may be used to prepare
evidence during a trial.

### External Resources:

Policies and Procedures

What is a Digital Forensics Analyst?

Digital forensics is the science of collecting evidence from computer systems
to a standard that will be accepted in a court of law. Like DNA or fingerprints,
digital evidence is mostly latent. Latent means that the evidence cannot be seen
with the naked eye; rather it must be interpreted using a machine or process.


Computer forensics analysts are known by a variety of other job titles, such as
forensic computer examiner, digital forensic examiner, and computer forensic
detective. Forensics analysts might work for a police or security service, a
bank, a computer security service organization, or within a cybersecurity team
in a large organization.

They use specialist tools and investigative skills to recover information from
computer systems, memory, and storage, possibly working in cooperation with law
enforcement officials to investigate cybercrimes or extract electronic evidence
related to other types of crime.

Another role is to analyze evidence (as an expert witness, for example) to help
organizations or individuals defend themselves in a legal case. Forensics
analysts may be called upon by IT technology or security groups to assist in
planning IT systems and processes to ensure that evidence will be properly
handled during a cybersecurity incident.

As part of a CSIRT or SOC, a forensics analyst may play several roles following
a security incident or in general support of cybersecurity, such as:

	• Investigating and reconstructing the cause of a cybersecurity incident.

	• Investigating whether any crimes, compliance violations, or inappropriate
  behavior have occurred.

	• Following forensics procedures to protect evidence that may be needed if a
  crime has occurred.

	• Determining if sensitive, protected data has been exposed.

	• Contributing to and supporting processes and tools used to protect evidence
  and ensure compliance.

	• Supporting ongoing audit processes and record maintenance.


What are Digital Forensics Procedures?

A forensics investigation will entail the following procedures within four
general phases:

1. Identification

	• Ensure that the scene is safe. Threat to life or injury takes precedence
  over evidence collection.

	• Secure the scene to prevent contamination of evidence. Record the scene
  using video and identify witnesses for interview.

	• Identify the scope of evidence to be collected.

2. Collection

	• Ensure authorization to collect the evidence using tools and methods that
  will withstand legal scrutiny.

	• Document and prove the integrity of evidence as it is collected and ensure
  that it is stored in secure, tamper-evident packaging.

3. Analysis

	• Create a copy of evidence for analysis, ensuring that the copy can be
  related directly to the primary evidence source.

	• Use repeatable methods and tools to analyze the evidence.

4. Reporting

	• Create a report of the methods and tools used, and present findings and
  conclusions.


Forensics Analyst Ethics -

It is important to note that strong ethical principles must guide forensics analysis.

	• Analysis must be performed without bias. Conclusions and opinions should be
  formed only from the direct evidence under analysis.

	• Analysis methods must be repeatable by third parties with access to the same
  evidence.

	• Ideally, the evidence must not be changed or manipulated. If a device used
  as evidence must be manipulated to facilitate analysis (disabling the lock
  feature of a mobile phone or preventing a remote wipe for example), the
  reasons for doing so must be sound and the process of doing so must be recorded.


NOTE: Defense counsel may try to use any deviation of good ethical and
professional behavior to have the forensics investigator's findings dismissed.


What is work product retention? -

Refers to the way in which a forensic examiner is retained (hired) to
investigate a case. In a civil or criminal trial, the principles of discovery and
disclosure govern the exchange of evidence between prosecution and defense.

In terms of digital forensics, there is potentially a distinction between the
evidence, such as a hard disk and associated image captured at a crime scene, and
analysis of the evidence, such as a forensics report highlighting artifacts
within the evidence that are relevant to the case.

Analysis of evidence created by an attorney for his or her client is protected
from disclosure by the work product doctrine. In this context, an attorney may
retain experts to perform the analysis.


NOTE: To be protected by the work product doctrine, the forensic investigator
must usually be retained by the attorney, rather than the company that the
attorney represents.


A fallback position is for the company to retain an investigator in a three-way
contract between the investigator, attorney, and the company, utilizing wording
of the form "at the direction of outside counsel in anticipation of legislation."

The investigator must report to counsel, and contact between counsel, the
investigator, and the company's CSIRT must be limited. They must not collude in
the process of producing the analysis. Defense counsel will try to test that the
work-product doctrine has been applied correctly.
