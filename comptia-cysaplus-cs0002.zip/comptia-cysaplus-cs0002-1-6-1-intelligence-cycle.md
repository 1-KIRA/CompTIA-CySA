## Episode Name: intelligence cycle


### Objectives:
Introduce learner to the importance and individual steps of the Intelligence Cycle which is the process of developing raw information into finished intelligence for policymakers to use in decision making and action.

### Code Snippets:


### External Resources:
https://www.recordedfuture.com/threat+intelligence/
