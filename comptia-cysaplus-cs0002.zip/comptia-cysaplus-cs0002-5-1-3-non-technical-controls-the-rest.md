## Episode Name: Non-Technical Controls - The Rest


### Objectives:

At the end of this episode, I will be able to:

Identify what non-technical controls are.

Identify what retention policies are, and why we have a need to apply them in
the organization.

Identify what the concept of data ownership is, and why it is important to help
secure organizational data.

Identify what the various roles associated with data are, and why we have a need
to use them to help govern and secure our data.

Identify what data sharing and privacy agreements are, and why we have a need to
apply them to our data.


### External Resources:

Non-Technical Controls - The Rest

What are Retention Policies? -

A set of policies, procedures, and tools for managing the storage of persistent
data.

Retention Standards -

﻿To meet compliance and e-discovery requirements, organizations may be legally
bound to retain certain types of data for a specified period.

This type of requirement will particularly affect financial data and security
log data.

Conversely, storage limitation principles in privacy legislation may prevent you
from retaining personal data for longer than is necessary.


Data Retention Policies and Procedures -

Data retention standards mean that detailed policies must be created to show when
and how to dispose of distinct types of data. It is important to include legal
counsel in your organization's data retention policies, as not meeting
requirements can bring about unwanted liability.

﻿Data retention refers to information that is kept for a defined period because of
a policy requirement.

Data preservation refers to information that is kept for a specific purpose
outside of this general policy. For example, you might preserve logs and
security data collected in response to a security incident where a court case is
expected.

A data retention policy uses backup and archiving tools to achieve its aims. Data
retention needs to be considered in the short and long term:

In the short term, files and records that change frequently might need retaining
for version control. Short term retention is also important in recovering from
security incidents. Short term retention is determined by how often the youngest
media sets are overwritten.

In the long term, data may need to be stored to meet legal requirements or to
follow company policies or industry standards. Any data that must be retained in
a version past the oldest sets should be moved to archive storage.

The recovery window is determined by the recovery point objective (RPO), which
is determined through business continuity planning.

A retention policy can either be based on redundancy (the number of copies of
each file that should be retained) or on a recovery window (the number of days
into the past that should be retained).


Secure Disposal of Data Policy -
﻿
Once the retention period for data has expired, the data must be disposed
of, typically using some sort of secure erase process.

Secure data disposal procedures are also important when it comes to repurposing
or releasing computer equipment, storage devices, and cloud storage services and
sites.


What are Data Ownership Policies and Roles? -

Data governance is a complex discipline and in a large business it will require
support from multiple organization roles. A company with formal data ownership
policies will define the following roles:

	• Data owner — A senior (executive) role with ultimate responsibility for
  maintaining the confidentiality, integrity, and availability of the information
  asset. The owner is responsible for labeling the asset (such as determining who
  should have access and determining the asset's criticality and sensitivity) and
  ensuring that it is protected with appropriate controls (access control, backup,
  retention, and so forth). The owner also typically selects a steward and
	custodian and directs their actions and sets the budget and resource
	allocation for sufficient controls.

	• Data steward — This role is primarily responsible for data quality. This
  involves tasks such as ensuring data is labeled and identified with appropriate
  metadata and that data is collected and stored in a format and with values that
  comply with applicable laws and regulations.

	• Data custodian — This role handles managing the system on which the data
  assets are stored. This includes responsibility for enforcing access control,
  encryption, and backup/recovery measures.

	• Privacy officer — This role is responsible for oversight of any
  PII/SPI/PHI assets managed by the company. The privacy officer ensures that
  the processing and disclosure of private/personal data complies with legal
  and regulatory frameworks, such as purpose limitation/consent, data
  minimization, data sovereignty, and data retention.


NOTE: For most businesses, a major challenge is in preventing the IT department
from becoming the owner of all the data the company processes or preventing IT
administrators from becoming de facto data owners by virtue of their privileged
access to the computer network.


What are Data Sharing & Privacy Agreements?

It is important to remember that although one can outsource virtually any
service or activity to a third party, one cannot outsource legal accountability
for these services or actions.

You are ultimately responsible for the services and actions that these third
parties take.

If they have any access to your data or systems, any security breach in their
organization (for example, unauthorized data sharing) is effectively a breach in
yours.

Issues of security risk awareness, shared duties, and contractual
responsibilities can be set out in a formal legal agreement. The following
types of agreements are common:

	• Service level agreement (SLA) — A contractual agreement setting out the
  detailed terms under which a service is provided. This can include terms for
  security access controls and risk assessments plus processing requirements for
  confidential and private data.

	• Interconnection security agreement (ISA) — ISAs are defined by
  NIST's SP800-47 "Security Guide for Interconnecting Information Technology
	Systems". Any federal agency interconnecting its IT system to a third party
	must create an ISA to govern the relationship. An ISA sets out a security risk
	awareness process and commits the agency and supplier to implementing security
	controls.

	• Non-disclosure agreement (NDA) — Legal basis for protecting information
	assets. NDAs are used between companies and employees, between companies and
	contractors, and between two companies. If the employee or contractor breaks
	this agreement and does share such information, they may face legal
	consequences. NDAs are useful because they deter employees and contractors
	from violating the trust that an employee places in them.

	• Data sharing and use agreement — Under privacy regulations such as GDPR or
  HIPAA, personal data can only be collected for a specific purpose. Datasets
	can be subject to pseudonymization or deidentification to remove personal
	data, but there are risks of reidentification if combined with other data
	sources. A data sharing and use agreement is a legal means of preventing this
	risk. It can specify terms for the way a dataset can be analyzed and proscribe
	the use of reidentification techniques.
