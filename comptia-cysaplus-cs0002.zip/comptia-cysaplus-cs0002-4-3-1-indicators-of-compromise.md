## Episode Name: indicators of compromise


### Objectives:
identify methods for distinguishing IoC by examining network, host, and application related activity for IoC attributes.

### Code Snippets:


### External Resources:
