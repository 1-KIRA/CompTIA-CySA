## Episode Name: endpoint behavior analysis


### Objectives:
Assess known-good endpoint behavior in terms of processes and services. Criticize unknown anomalous processes to discover possible evidence of malware. 

### Code Snippets:


### External Resources:
+ https://docs.microsoft.com/en-us/advanced-threat-analytics/what-is-ata
+ https://www.splunk.com/en_us/software/user-behavior-analytics.html
