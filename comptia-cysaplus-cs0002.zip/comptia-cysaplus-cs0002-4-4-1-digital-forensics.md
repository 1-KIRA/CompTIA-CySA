## Episode Name: digital forensics


### Objectives:
review the digital forensics procedures and explore common digital forensics tactics and tools for performing forensic analysis on traditional computer, mobile, and virtual hosts.

### Code Snippets:


### External Resources:
+ https://www.magnetforensics.com/resources/magnet+ram-capture/
+ https://tools.ietf.org/html/rfc3227
