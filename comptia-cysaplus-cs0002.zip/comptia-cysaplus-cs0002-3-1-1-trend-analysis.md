## Episode Name: trend analysis


### Objectives:
Define the purpose, application, metrics and drawbacks of trend analysis.

### Code Snippets:


### External Resources:
