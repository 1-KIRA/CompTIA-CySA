## Episode Name: hardware assurance


### Objectives:
Discover hardware security mechanisms and technologies such as TPMs, Anti-Tamper devices, eFuse, Self-Encrypting Drives, and Secure Processing. 

### Code Snippets:


### External Resources:
+ https://www.ncipher.com/products
