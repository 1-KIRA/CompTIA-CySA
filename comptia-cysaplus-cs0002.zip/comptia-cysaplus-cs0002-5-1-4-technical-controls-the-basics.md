## Episode Name: Technical Controls - The Basics


### Objectives:

At the end of this episode, I will be able to:

Identify what Technical controls are.

Identify what access controls are, and why we have a need to apply them in the
organization.

Identify what the concept of geographic access requirements is, and why awareness
of it is important to help secure organizational data.

Identify what encryption is, and why we have a need to apply it to our data at
rest, in transit, and in use to help ensure the confidentiality and security of
data.

Identify what data loss prevention (DLP) technology is, and why we have a need to
apply it to our data.


### External Resources:

Technical Controls - The Basics

Access Controls -

﻿An access control model can be applied to any type of data or software resource
but is most strongly associated with network, file system, and database security.

With file system security, each object in the file system has an ACL associated
with it. The ACL contains a list of accounts (principals) allowed to access the
resource and the permissions they have over it.

Each record in the ACL is called an access control entry (ACE).

The order of ACEs in the ACL is important in determining effective permissions
for a given account.

NOTE: ACLs can be enforced by a file system that supports permissions, such as
NTFS, ext3/ext4, or ZFS.


Database security is similar, but the range of objects that can be secured with
fine-grained permissions is wider.

Objects in a database schema include the database itself, tables, views, rows
(records), and columns (fields).

NOTE: Different policies can be applied for statements, such as SELECT,
INSERT, UPDATE, and DELETE.


Geographic Access Requirements -

Geographic access requirements fall into two different scenarios.

1. Storage locations might have to be carefully selected to mitigate data
sovereignty issues - Most cloud providers allow choice of data centers for
processing and storage, ensuring that information is not illegally transferred
from a particular privacy jurisdiction without consent.

2. Employees needing access from multiple geographic locations - Cloud-based
file and database services can apply constraint-based access controls to
validate the user's geographic location before authorizing access.


What is encryption and why do I need to know about it? -

Encryption mitigates the risk of the access controls enforced by the operating
system or database from being circumvented or compromised.

When deploying a cryptographic system to protect data assets, consideration must
be given to all the ways that information could potentially be intercepted.

This means thinking beyond the simple concept of a data file stored on a disk
to considering the state when data is moved over a network or is being processed
on a host.


Data at Rest -

﻿This state means that the data is in persistent storage media.

In this state, it is usually possible to encrypt the data, using techniques such
as whole disk encryption, database encryption, and file- or folder-level
encryption.


Data in Transit (or Data in Motion) -

﻿This is the state when data is transmitted over a network.

In this state, data can be protected by a transport encryption protocol, such as
TLS or IPsec.

﻿NOTE: With data at rest, there is a greater encryption challenge than with data
in transit as the encryption keys must be kept secure for longer. Transport
encryption can use ephemeral (session) keys.


Data in Use -

﻿This is the state when data is present in volatile memory, such as system RAM
or CPU registers and cache.

When a user works with data, that data usually needs to be decrypted as it goes
from in rest to in use.

The data may stay decrypted for an entire work session, which puts it at risk.
Secure processing mechanisms such as Intel Software Guard Extensions are able
to encrypt data as it exists in memory, so that an untrusted process cannot
decode the information. This uses a secure enclave and requires a hardware root
of trust.


What is Data Loss Prevention (DLP)? -

Data loss prevention (DLP) products automate the discovery and classification of
data types and enforce rules so that data is not viewed or transferred without a
proper authorization. Such solutions will usually consist of the following
components:

	• Policy server — To configure classification, confidentiality, and privacy
  rules and policies, log incidents, and compile reports

	• Endpoint agents — To enforce policy on client computers, even when they are
  not connected to the network

	• Network agents — To scan communications at network borders and interface
  with web and messaging servers to enforce policy


DLP agents scan content in structured formats, such as a database with a formal
access control model or unstructured formats, such as email or word processing
documents.

A file cracking process is applied to unstructured data to render it in a
consistent scannable format.

The transfer of content to removable media, such as USB devices, or by email,
instant messaging, or even social media, can then be blocked if it does not
conform to a predefined policy.

NOTE: Most DLP solutions can extend the protection mechanisms to cloud storage
services, using either a proxy to mediate access or the cloud service provider's
API to perform scanning and policy enforcement.

NOTE: As well as being able to scan cloud locations, DLP components are often
provisioned as a cloud-based service.


Remediation is the action the DLP software takes when it detects a policy
violation. The following remediation mechanisms are typical:

	• Alert only — The copying is allowed, but the management system records an
  incident and may alert an administrator

	• Block — The user is prevented from copying the original file but retains
  access to it. The user may or may not be alerted to the policy violation, but
  it will be logged as an incident by the management engine

	• Quarantine — Access to the original file is denied to the user (or
  possibly any user); This might be accomplished by encrypting the file in
  place or by moving it to a quarantine area in the file system

	• Tombstone — The original file is quarantined and replaced with one
  describing the policy violation and how the user can release it again


When it is configured to protect a communications channel such as email, DLP
remediation might take place using client-side or server-side mechanisms.

For example, some DLP solutions prevent the actual attaching of files to the
email before it is sent. Others might scan the email attachments and message
contents, and then strip out certain data or stop the email from reaching its
destination.


DLP uses various methods to define data that should be protected:

	• Classification — A rule might be based on a confidentiality classification
  tag or label attached to the data. Data could be tagged manually or using
  automated detection tools. The DLP solution might support other types of label,
  such as discrete data type, retention policy, and so on.

	• Dictionary — A dictionary is a set of patterns that should be matched.
  Dictionary terms could be made from keywords or regex pattern matches. The
  use of patterns can be tuned within a rule to reduce false positives. For
  example, you might require a minimum number of instances of a pattern, look
  for the incidence of two or more patterns in close proximity, or define
  patterns with different confidence accuracy levels.

	• Policy template — A template contains dictionaries optimized for data points
  in a regulatory or legislative schema. A DLP solution will contain a number of
  templates designed for HIPAA, GDPR. For example, Microsoft's US PII template
  can match Individual Taxpayer Identification Numbers (ITINs), Social Security
  Numbers (SSNs), and passport numbers.

	• Exact data match (EDM) — Pattern matching can generate large numbers of
  false positives. EDM uses a structured database of string values to match. Each
  record in the source can contain a number of fields. The source is then
  converted to an index, which uses hashed forms of the strings (fingerprints) so
  that they can be loaded to the policy engine without compromising
  confidentiality or privacy issues. The rules engine can be configured to match
  as many fields as required from each indexed record. For example, a travel
  company might have a list of actual passport numbers of their customers. It is
  not appropriate to load these numbers into a DLP filter, so they could use EDM
  to match fingerprints of the numbers instead.

	• Document matching — A whole document can be matched using a fingerprint, but
  it is quite easy to modify a file so that it no longer matches the fingerprint.
  To compensate for this risk, partial document matching creates a series of
  hashes for overlapping parts of the document. These hashes can match content
  that has been copied from the document or used in a different order in another
  file.

	• Statistical/lexicon — A further refinement of partial document matching is
  to use machine learning to analyze a range of data sources. The policy engine
  scans a range of source documents and performs statistical analysis to create
  a "vocabulary" or lexicon of the way sensitive data, such as a patient's medical
  notes or a patent application, is written.
