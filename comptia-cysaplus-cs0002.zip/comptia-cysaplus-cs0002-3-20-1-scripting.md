## Episode Name: scripting


### Objectives:
explore common scripting languages like Bash and PowerShell so that you can begin to engage in simple automation of those repetitive tasks. 

### Code Snippets:


### External Resources:
