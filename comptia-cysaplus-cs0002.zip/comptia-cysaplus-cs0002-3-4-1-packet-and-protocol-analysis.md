## Episode Name: packet and protocol analysis


### Objectives:
Utilize network sniffers like Wireshark to observe network packets and protocols for evidence of a security event.

### Code Snippets:


### External Resources:
