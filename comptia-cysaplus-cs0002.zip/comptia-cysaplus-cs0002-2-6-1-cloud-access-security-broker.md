## Episode Name: cloud access security broker


### Objectives:
Articulate how CASB can support enterprise security when managing infrastructure.

### Code Snippets:


### External Resources:
