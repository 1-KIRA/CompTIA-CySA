## Episode Name: inhibitors to remediation


### Objectives:
Explore common impediments to remediating vulnerabilities. This includes technical constraints to bureaucracies. 

### Code Snippets:


### External Resources:
+ https://ibmsystemsmag.com/IBM-Z/10/2019/closing-cobol-programming-skills-gap
