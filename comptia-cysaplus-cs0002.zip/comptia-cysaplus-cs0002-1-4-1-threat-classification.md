## Episode Name: threat classification


### Objectives:
Define and explain the importance of threat classifications, to increase the learner's vocabulary and body of knowledge so that further security related conversations can be had. 

### Code Snippets:


### External Resources:
+ https://medium.com/datadriveninvestor/known-knowns-unknown-knowns-and-unknown-unknowns-b35013fb350d
+ https://portswigger.net/daily-swig/zero-day
+ https://www.fireeye.com/current-threats/apt-groups.html
