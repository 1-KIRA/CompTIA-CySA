## Episode Name: network architecture and segmentation


### Objectives:
Explain how a securely designed network can uses technologies such as SDN, VPC, VPN and Segmentation can better withstand constant attack. 

### Code Snippets:


### External Resources:
