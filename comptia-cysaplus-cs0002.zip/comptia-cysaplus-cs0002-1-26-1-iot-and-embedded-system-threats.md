## Episode Name: iot and embedded system threats


### Objectives:
discern the threats that are associated with IoT and embedded systems which will give you the knowledge to better secure those systems

### Code Snippets:


### External Resources:
+ https://www.cvedetails.com/cve/CVE+2018-6831/
+ https://www.vdoo.com/blog/vdoo+has-found-major-vulnerabilities-in-foscam-cameras
+ https://www.wired.com/story/vxworks+vulnerabilities-urgent11/
+ https://thehackernews.com/2020/04/fpga+chip-vulnerability.html
