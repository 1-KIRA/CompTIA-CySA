## Episode Name: honeypots and active defense


### Objectives:
+ Explain the purpose of active defense and apply active defense concepts.
+ Define a honeypot.  
+ Recognize when a honey pot is an appropriate active defense solution.
+ Explain how a honeypot fits into a security infrastructure.

### Code Snippets:


### External Resources:
