## Episode Name: virtual desktop infrastructure and containerization


### Objectives:
Explain how virtualization solutions such as Virtual Desktop Environments and containerization can help bolster security by isolating processes and operating systems.

### Code Snippets:


### External Resources:
+ https://ravada.upc.edu/
