## Episode Name: mobile technology threats


### Objectives:
Familiarize learner with vulnerabilities associated with mobile technology threats such as BYOD environment difficulties and mobile OS vulnerabilities as well as security techniques for mobile and mobile management software. 

### Code Snippets:


### External Resources:
+ https://www.theregister.co.uk/2020/04/08/xhelper_android_malware/
+ https://medium.com/pen-bold-kiln-press/best-google-play-store-alternatives-30c759de1c26
+ https://www.air-watch.com/
+ https://www.mobileiron.com/en
