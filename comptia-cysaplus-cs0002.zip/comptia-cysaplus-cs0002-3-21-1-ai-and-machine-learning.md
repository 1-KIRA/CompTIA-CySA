## Episode Name: ai and machine learning


### Objectives:
distinguish the differences and relationships between AI, ML, and Deep Learning(DL).

### Code Snippets:


### External Resources:
