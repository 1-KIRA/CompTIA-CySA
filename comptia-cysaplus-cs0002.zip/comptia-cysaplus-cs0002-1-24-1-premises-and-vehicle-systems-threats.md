## Episode Name: premises and vehicle systems threats


### Objectives:
explore common threats and vulnerabilities that are pointed towards our Building Automation systems and fleet vehicles so that we can better protect our environments from every possible angle.

### Code Snippets:


### External Resources:
+ https://www.johnsoncontrols.com/building+automation-and-controls/building-management/building-automation-systems-bas
+ https://www.forescout.com/company/blog/vulnerabilities-in-building-automation-systems/
+ https://www.wired.com/2015/07/hackers+remotely-kill-jeep-highway/
