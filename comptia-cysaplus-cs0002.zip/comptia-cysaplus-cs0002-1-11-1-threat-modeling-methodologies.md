## Episode Name: threat modeling methodologies


### Objectives:
Familiarize learner with threat modeling methodologies so that they can employ the best method for a given environment.

### Code Snippets:


### External Resources:
+ https://www.mitre.org/sites/default/files/publications/pr_18-1174-ngci-cyber-threat-modeling.pdf
