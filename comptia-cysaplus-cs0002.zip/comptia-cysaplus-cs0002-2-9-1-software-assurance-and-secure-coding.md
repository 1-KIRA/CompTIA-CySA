## Episode Name: software assurance and secure coding


### Objectives:
Identify software assurance and secure coding practices and techniqes SDLC integration, Input Validation, and Parameterized Queries to build apps with more robust security baked in.

### Code Snippets:


### External Resources:
+ https://cheatsheetseries.owasp.org/cheatsheets/Input_Validation_Cheat_Sheet.html
+ https://www.php.net/manual/en/function.htmlspecialchars.php
