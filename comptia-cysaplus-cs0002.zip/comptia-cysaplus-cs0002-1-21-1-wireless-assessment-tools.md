## Episode Name: wireless assessment tools


### Objectives:
Explore the output of wireless assessment tools such as aircrack-ng, reaver, and ocl-hashcat when assessing the risk of a given organization's wireless network. 

### Code Snippets:


### External Resources:
+ https://github.com/t6x/reaver+wps-fork-t6x
