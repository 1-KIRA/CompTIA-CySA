## Episode Name: threat actors


### Objectives:
Familiarize learner with they types of people, their skillsets, and motivations that could possibly pose a threat

### Code Snippets:


### External Resources:
