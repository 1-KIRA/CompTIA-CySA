## Episode Name: How do we Prioritize & Communicate Risk?


### Objectives:

At the end of this episode, I will be able to:

Identify what the 4 different risk response strategies are.

Identify how we prioritize and select security controls and why the
Return On Security Investment (ROSI) is an important part of that activity.

Understand how to calculate the Return On Security Investment (ROSI) using the
formulas discussed.


### External Resources:

How do we Prioritize & Communicate Risk?

** NOTE: MAKE SURE TO LOOK AT THE 5-2-4-How do we Prioritize & Communicate Risk.pptx
slide deck for the formulas mentioned in this episode !!


Risk response strategies are as follows:

	• Risk mitigation (or remediation) is the overall process of reducing
  exposure to, or the effects of, risk factors.

There are several ways of mitigating risk. If you deploy a countermeasure that
reduces exposure to a threat or vulnerability, that is risk deterrence (or
reduction).

Risk reduction refers to controls that can either make a risk incident less
likely or less costly (or perhaps both).

	• Risk avoidance means that you stop doing the activity that is risk-bearing.

NOTE: Avoidance is often NOT a credible choice.

	• Risk transference (or sharing) means assigning risk to a third party (such
  as an insurance company or a contract with a supplier that defines liabilities).

	• Risk acceptance (or retention) means that no countermeasures are put in
  place either because the level of risk does not justify the cost or because
  there will be unavoidable delay before the countermeasures are deployed. In
  this case, you should continue to monitor the risk (as opposed to ignoring it).


Security Control Prioritization and Selection -

The criteria for selecting whether to implement a security control and whether
to prioritize the deployment of one control over another, will depend on several
factors:

	• Whether the control is part of a framework or best practice guide or
  required for regulatory reasons

	• The cost of the control both in terms of acquisition and ongoing maintenance
  and support

	• The level of risk that the control is designed to mitigate


Judged on purely a cost basis, the return on security investment (ROSI) is a
percentage value that can be determined by calculating a new annual loss
expectancy (ALE), based on the reduction in loss that will be created by the
security control introduced.

The formula for calculating ROSI is:

	((ALE - ALEm) – C) / C = ROSI

where C is the cost of the security control, ALE is the ALE before controls,
and ALEm is after controls.


ALE – ALEm can also be expressed as a percentage mitigation ratio (MR), so the
ROSI can also be written as:

	((ALE * MR) – C) / C = ROSI


Engineering Tradeoffs -

The reason why risk is managed rather than eliminated outright is because risk
is not always in opposition to an organization's goals. That is why risk
management is a process of understanding what risks you can take, as long as the
reward is worth the risk.

An engineering tradeoff occurs when the use of a risk mitigation solution has
its own risks or special costs.

For example, a company incurs losses of $500,000 each year because of fraudulent
transactions. An improved authentication system will reduce losses by 50%-75%
and will cost $150,000 each year in licensing and equipment costs.

However, analysis shows that it will also incur costs of $100,000 per year to
the support department because of increased complexity. In this case, the ROSI is
marginal at best.

The calculation between elevated risk versus better convenience is one that
companies are forced into all the time.


Communication of Risk Factors -

To ensure that the business stakeholders understand each risk scenario, you
should articulate it such that the cause and effect can clearly be understood by
the business owner of the asset.

The style of the content and output of any risk analysis must reflect the
framework and jurisdiction within which the organization is operating.


Risk Register -

A risk register is a document showing the results of risk assessments in a
comprehensible format.

The register may resemble the traffic light grid with columns for impact and
likelihood ratings, date of identification, description, countermeasures,
owner/route for escalation, and status.

A risk register should be shared between stakeholders (executives, department
managers, and senior technicians) so that they understand the risks associated
with the workflows that they manage.


Exception Management -

Written policies and procedures are never a perfect match for the environment in
which they must be implemented. A control might be too expensive, there might
not be qualified staff to operate it, or it might be incompatible with an
application or hardware platform.

Where a function or asset is noncompliant, there should be a formal process of
exception management to document each case. A typical exception request will
include the following information:

	• Business process and assets affected

	• Personnel involved (data owner, data processors, and additional stakeholders)

	• Reason for the exception

	• Risk assessment plus compensating controls to mitigate the added risk
  (additional monitoring or logging activity for instance)

	• Duration of the exception and steps that will be taken to achieve compliance


If a policy or procedure generates large numbers of exception requests, it will
be necessary to redesign the control so that it can be implemented more easily.
