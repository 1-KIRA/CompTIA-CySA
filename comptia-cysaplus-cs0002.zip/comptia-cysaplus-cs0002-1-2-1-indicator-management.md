## Episode Name: indicator management


### Objectives:
Define standards used to manage and share information about threats and threat indicators.

### Code Snippets:


### External Resources:
+ https://oasis-open.github.io/cti-documentation/
+ https://misp-project.org
+ https://exchange.xforce.ibmcloud.com/
