## Episode Name: flow analysis


### Objectives:
Use flow analysis tools to highlight trends in network traffic from applications, endpoints, ports.

### Code Snippets:


### External Resources:
+ https://openargus.org/using-argus
