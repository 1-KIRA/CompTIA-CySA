## Episode Name: cloud infrastructure assessment tools


### Objectives:
Explore the output of cloud infrastructure assessment tools such as ScoutSuite, Prowler, and Pacu when assessing the risk of a given organization's cloud-based systems.

### Code Snippets:


### External Resources:
+ https://github.com/RhinoSecurityLabs/pacu
+ https://github.com/RhinoSecurityLabs/cloudgoat
+ https://github.com/toniblyx/prowler
+ https://github.com/nccgroup/ScoutSuite
