## Episode Name: How do we Calculate Risk?


### Objectives:

At the end of this episode, I will be able to:

Identify how to calculate risk.

Identify what the three methods of making calculations of risk during an
assessment are.

Understand what the various formulas are that help to perform a Quantitative
Risk assessment.


### External Resources:

How do we Calculate Risk?

** NOTE: MAKE SURE TO LOOK AT THE 5-2-2-How do we Calculate and Analyze Risk.pptx
slide deck for the formulas mentioned in this episode !!


Risk Calculation -

Risk calculation or analysis is a process within the overall risk management
framework to assess the probability (or likelihood) and magnitude (or impact) of
each threat scenario.

Calculating risk is complex in practice, but the method can be simply stated as
finding the product of these two factors:

	• Probability is the chance of a threat being realized

	• Magnitude is the impact of a successful exploit or a risk event

NOTE: Magnitude may be determined by factors such as the value of the asset or
the cost of disruption if the asset is compromised.

	Probability * Magnitude = Risk


There are three methods of making calculations of risk during an assessment:
quantitative, qualitative, and semi-quantitative.

Quantitative Risk Calculation -

A quantitative assessment of risk attempts to assign concrete values to the
elements of risk.

Probability is expressed as a percentage and magnitude as a cost (monetary)
value, as in the following formula:

	AV (Asset Value) x EF (Exposure Factor) = SLE (Single Loss Expectancy)

EF is the percentage of the asset's value that would be lost. The single loss
expectancy (SLE) value is the financial loss that is expected from a specific
adverse event. For example, if the asset value is $50,000 and EF is 5%, the SLE
calculation is as follows:

	$50,000 * .05 = $2,500

If you know or can estimate how many times this loss is likely to occur in a
year, you can calculate the risk cost on an annual basis:

	SLE (Single Loss Expectancy) x ARO (Annual Rate of Occurrence) = ALE (Annual Loss Expectancy)


NOTE: The problem with quantitative risk assessment is that the process of
determining and assigning these values can be complex and time consuming.


Qualitative Risk Calculation -

Qualitative analysis is generally scenario-based.

The qualitative approach seeks out people's opinions of which risk factors are
significant.

Qualitative analysis uses simple labels and categories to measure the likelihood
and impact of risk.

For example, impact ratings can be severe/high, moderate/medium, or low; and
likelihood ratings can be likely, unlikely, or rare.

NOTE: Another simple approach is the "Traffic Light" impact grid. For each risk,
a simple Red, Amber, or Green indicator can be put into each column to represent
the severity of the risk, its likelihood, cost of controls, and so on.


Semi-Quantitative Risk Calculation -

A semi-quantitative analysis method exists because it is impossible for a purely
quantitative risk assessment to exist given that some issues defy numbers.

A semi-quantitative analysis attempts to find a middle ground between the risk
analysis types to create a hybrid method.
