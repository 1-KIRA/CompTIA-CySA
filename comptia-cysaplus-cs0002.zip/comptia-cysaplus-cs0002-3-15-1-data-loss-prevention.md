## Episode Name: data loss prevention


### Objectives:
 explore the use of Data Loss Protection(DLP) and discover how DLP is used to automate the detection and securing of sensitive data.

### Code Snippets:


### External Resources:
