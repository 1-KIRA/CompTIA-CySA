## Episode Name: Frameworks, Audits and Policy


### Objectives:

At the end of this episode, I will be able to:

Identify what an Enterprise Security Architecture (ESA) is.

Identify what an organizational Maturity Model is.

Identify what a risk-based framework is.

Identify what an audit is.

Identify what Quality Assurance, Quality Control, Verification and Validation
are, and what they are used for.


### External Resources:

Frameworks, Audits and Policy

What is an Enterprise Security Architecture (ESA)? -

IT governance or IT Service Management (ITSM) is a concept in which stakeholders
ensure that those responsible for selecting, deploying, and operating IT
resources in an enterprise are performing their duties in a way that fulfills
the enterprise's strategies and objectives and creates value for the business. As
well as evaluating IT management's performance, framework based governance seeks
to mitigate the risks that are associated with IT service delivery.

An enterprise security architecture (ESA) framework is a list of activities and
objectives undertaken to mitigate risks. Frameworks can shape company policies
and provide checklists of procedures, activities, and technologies that should
ideally be in place.

The use of a framework allows an organization to make an objective statement of
its current cybersecurity capabilities, identify a target level of capability,
and prioritize investments to achieve that target. This is valuable for giving
a structure to internal risk management procedures and also provides an
externally verifiable statement of regulatory compliance.

Many ESA frameworks adopt a prescriptive approach. These frameworks are usually
driven by regulatory compliance factors.

In a prescriptive framework, the controls used in the framework must be deployed
by the organization. Each organization will be audited to ensure compliance.


Examples of ESA frameworks include:

	• Control Objectives for Information and Related Technology (COBIT)
	• ITIL
	• International Organization for Standardization (ISO) 27001
	• Payment Card Industry Data Security Standard (PCI DSS)


Prescriptive frameworks use the concept of a maturity model (or something
similar) to assess how well-developed the organization's security capabilities
are.

In most models, organizations start out with a reactive approach to
security — that is, something bad happens and they scramble to fix it.

The fix gives them some capability to detect and prevent attacks in the future,
and the maturity model shows how successful they are in developing that capability.

The maturity model will define a number of tiers for the organization to
progress through to full maturity.

At the top end of the maturity model are organizations with risk-driven business
policies and processes, procedures for optimizing and continuously monitoring
controls, and the capability to investigate and communicate threat intelligence
to other companies.

Maturity models review an organization against expected goals and determine the
level of risk the organization is exposed to based on the degree to which it is
currently meeting those goals. This enables the reviewer to gain a more accurate
perspective of how an organization's products or services may be putting the
organization at risk, and guides risk management strategies as a response.

Example:

The Capability Maturity Model Integrated (CMMI) is intended to institutionalize
a collection of pre-defined delivery practices and ensure their consistent
execution so as to increase the probability that a team or organization can
successfully complete projects. The definition of “successful” includes
completing the project on time and in budget.

In CMMI models with a staged representation, there are five maturity levels
designated by the numbers 1 through 5 as shown below:

 1. Initial - process is not standardized or repeatable; poorly controlled and
 reactive

 2. Managed - process is characterized for projects but is often reactive

 3. Defined - process is characterized for the organization and is proactive

 4. Quantitatively Managed - process is measured and controlled

 5. Optimizing - focus on process improvement


What is a Risk-Based Framework? -

Prescriptive frameworks obviously address risk, but the top-down approach to
control selection can make it difficult for the framework to keep pace with a
continually evolving threat landscape.

These concerns are addressed by adopting a risk-based framework. This recognizes
that outside of strict regulatory compliance requirements, not all parts of a
framework apply to every type of business or institution.


The NIST Cybersecurity Framework (nist.gov/cyberframework) focuses exclusively
on IT security rather than IT service provision more generally. It can also be
described as a risk-based, rather than prescriptive, approach. The framework
consists of three parts: a core, implementation tiers, and profiles.

	• Framework core — identifies five cybersecurity functions (Identify, Protect,
  Detect, Respond, and Recover). Each function can be divided into categories
  and subcategories. Subcategories can also be associated with one or more
  Informative References, which are examples of specific best practice guides or
  configuration instructions/templates.

	• Implementation tiers — assess how closely core functions are integrated with
  the organization's overall risk management process. The tiers are classed as
  Partial, Risk Informed, Repeatable, and Adaptive. At the adaptive tier, the
  organization has a process of continuous improvement based on lessons learned
  from incident analysis. Policies and procedures are all risk-informed, and the
  organization shares risk and threat information with partners.

	• Framework profiles — used to supply statements of current cybersecurity
  outcomes and target cybersecurity outcomes. This allows the organization to
  identify investments that will be most productive in closing the gap in
  cybersecurity capabilities shown by comparison of the current and target
  profiles.


What about Audit and Assessments? -

What are Audits? -

Auditing is similar to evaluation and assessment strategies but takes a more
rigid approach to reviewing the organization. The auditor has a predefined
baseline that they compare the organization's current state to, which helps the
auditor find any specific violations that require remediation.

Regular formal regulatory audits by external auditors will be a requirement of
any business working in a regulated industry, such as payment card processing or
healthcare information processing. The formal audit will take place against the
framework and maturity model used by the regulator. Typically, organizations
prepare for such audits by performing mock compliance audits.


What does Assessment and Compliance have to do with audits? -

Quality processes are how an organization tests a system to identify whether
it complies with a set of requirements and expectations. These requirements and
expectations can be driven by risk-based assessments, or they can be driven by
internal and external compliance factors, such as industry regulations and
company-defined quality standards.


What exactly are Quality Control (QC) and Quality Assurance (QA)? -

﻿Quality control (QC) is the process of determining whether a system is free from
defects or deficiencies. QC procedures are themselves defined by a quality
assurance (QA) process, which analyzes what constitutes "quality" and how it can
be measured and checked.


What are Verification and Validation (V&V)? -

At a product or software development level, these concepts of QA and QC are
often distinguished as verification and validation (V&V):

Verification is a compliance-testing process to ensure that the security system
meets the requirements of a framework or regulatory environment, or more
generally, that a product or system meets its design goals.

Validation is the process of determining whether the security system is
fit-for-purpose (so that, for instance, its design goals meet the requirements
for a secure system).


What are Assessments and Evaluations? -

You can also interpret these differences by comparing an assessment with an
evaluation:

Assessment tests the subject against a checklist of requirements (Is the
network protected by a properly configured firewall? Do all end stations have
up-to-date virus scanners installed?) An assessment proceeds in a highly
structured way and measures absolute standards (scored against a benchmark or
checklist, for instance).

Evaluation is a less methodical process aimed at examining outcomes or
literally "proving usefulness" (Were there security breaches? What was the
response to an incident?). Evaluation is more likely to use comparative
measurements and is more likely to depend on the judgement of the evaluator than
on a checklist or framework.
﻿

What about Scheduled Reviews and Continual Improvement? -

Remember that the last step in incident response is a "lessons learned" review
and report, in which any improvements to procedures or controls that could have
helped to mitigate the incident are discussed.

A system of scheduled reviews extends this "lessons learned" approach to a
regular calendar-based evaluation.

To prepare for a scheduled review you will complete a report detailing some of
the following:

	• Major incidents experienced in the last period

	• Trends and analysis of threat intelligence, both directly affecting your
  company and in the general cybersecurity industry

	• Changes and additions to security controls and systems

	• Progress toward adopting or updating compliance with a framework or maturity
  model


What about Continual improvement? -

Making small, incremental gains to products and services by identifying defects
and inefficiencies through techniques such as root cause analysis.

NOTE: Continual improvement is often guided by best practice models such as
Six Sigma and Lean.


What about Continuous Monitoring? -

In an organization with "immature" security capabilities, controls are only
seriously investigated after some sort of incident. In contrast to this reactive
approach, continuous security monitoring (CSM), also referred to as security
continuous monitoring, is a process of continual risk reassessment.

Rather than an ad hoc process driven by incident response, CSM is an ongoing
effort to obtain information vital in managing risk within the organization. CSM
ensures that all key assets and risk areas are under constant surveillance by
finely tuned systems that can detect a wide variety of issues.

This means maintaining an elevated level of awareness of emerging threats and
vulnerabilities. It also refers to performing routine audits of rights and
privileges, plus other key security metrics in "real time" (that is, every day
rather than every week or every month, for example).

These are compared against the initial baseline configuration to identify
variations that could represent a security incident that must be investigated.

Continuous monitoring can turn a reactive collection process into a proactive
one, enabling the organization to obtain security intelligence that is
comprehensive, accurate, up-to-date, and actionable.


NOTE: Care needs to be taken to identify the metrics that best represent the
risks to which an organization is most exposed.

Although the effective implementation and maintenance of a CSM capability is
complex and time-consuming, the result is that systems are continually monitored
for problems or potential problems, and a response can often be crafted as soon
as a problem is detected, minimizing or preventing damage.


NOTE: The US Department of Homeland Security has created a program named
continuous diagnostics and mitigation (CDM) (dhs.gov/cisa/cdm), which provides
US government agencies and departments with capabilities and tools to "identify
cybersecurity risks on an ongoing basis, prioritize these risks based upon
potential impacts, and enable cybersecurity personnel to mitigate the most
significant problems first."

NIST has published a guide to continuous security monitoring (SP 800-137).
