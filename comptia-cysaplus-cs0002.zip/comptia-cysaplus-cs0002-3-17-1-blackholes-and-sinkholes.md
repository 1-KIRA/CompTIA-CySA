## Episode Name: blackholes and sinkholes


### Objectives:
analyze two common methods for managing malicious traffic from both inside and outside of your network known as Blackholing and Sinkholing.

### Code Snippets:


### External Resources:
