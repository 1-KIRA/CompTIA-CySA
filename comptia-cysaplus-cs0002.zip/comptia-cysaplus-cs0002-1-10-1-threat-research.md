## Episode Name: threat research


### Objectives:
Introduce learner to utilizing threat research to better support organizational security

### Code Snippets:


### External Resources:
+ https://talosintelligence.com/reputation_center
+ https://mitre-attack.github.io/attack-navigator/enterprise/
+ https://attack.mitre.org/
