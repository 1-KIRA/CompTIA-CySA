## Episode Name: cloud service model threats


### Objectives:
Familiarize learner with cloud service models (SaaS, PaaS, IaaS) and their inherent vulnerabilities.

### Code Snippets:


### External Resources:
