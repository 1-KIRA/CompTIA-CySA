## Episode Name: incident response phases


### Objectives:
identify the 6 phases of Incident Response assessing characteristics that contribute to the severity/security level classification.

### Code Snippets:


### External Resources:
+ https://bok.ahima.org/PdfView?oid=76732
