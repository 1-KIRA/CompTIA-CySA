## Episode Name: dns analysis


### Objectives:
Determine DNS strategies used by malware to contact Command&Control servers and the detection and mitigation strategies used to combat it. 

### Code Snippets:


### External Resources:
+ https://www.ipvoid.com/dns+reputation/
+ https://github.com/baderj/domain_generation_algorithms
+ https://www.alexa.com/topsites
