## Episode Name: IAM Policies and Procedures


### Objectives:

At the end of this episode, I will be able to:

Identify what account management is, and how to use it effectively to help
provide appropriate IAM protections in an organization.

Identify what password policies are, and how to use them effectively to help
provide appropriate IAM protections in an organization.

Identify what an Acceptable Use Policy (AUP) is, and how to use one effectively
to help provide appropriate IAM protections in an organization.

Identify what data ownership is, the roles that support it, and how to use them
effectively to help provide appropriate IAM protections in an organization.

Identify what data retention is, the tools available to support it, and how to
use them effectively to help provide appropriate IAM protections in an
organization.


### External Resources:

IAM Policies and Procedures

Identity and access management (IAM) is the process of protecting how users and
devices are represented in the organization, as well as how users and devices
are granted access to resources based on this representation.


What are the IAM tasks that I should be aware of? -

An IAM system usually contains technical components like directory services and
repositories, access management tools, and systems that audit and report on ID
management capabilities. Typical IAM tasks might include:

	• Creating and deprovisioning accounts (onboarding and offboarding)

	• Managing accounts (resetting user passwords, updating certificates,
  managing permissions and authorizations, and synchronizing multiple identities)

	• Auditing account activity

	• Evaluating identity-based threats and vulnerabilities

	• Maintaining compliance with regulations


What are the Account Management Risks I need to know about? -

IAM must be supported by organizational policies and procedures, plus training.
Policy deviations can allow the creation of rogue accounts or allow improper
control of an account.

It is well known that adversaries target employees as a means of gaining access
to the network. It is also well known that password-based credentials are hugely
problematic.

These issues can be addressed by delivering training and education targeted to
different user groups backed up by security policies that ensure best practice.
You need to pay special attention to administrative staff:

	Privileged accounts — Administrators are often granted too many privileges or
  abuse accounts with "super" privileges for routine log-ons. Ensure that
  privileged accounts are very tightly audited.

	Shared accounts — Typically, simple SOHO networking devices do not allow for
  the creation of multiple accounts, and a single "Admin" account is used to
  manage the device. Such a shared account, where the password (or other
  authentication credential) is known to more than one person, breaks the
  principle of nonrepudiation and makes an accurate audit trail difficult to
  establish.


What are password policies, and why do I have to know about them? -

A password policy instructs users on best practice in choosing and maintaining
passwords. More generally, a credential management policy should instruct users
on how to keep their authentication method secure, whether this be a password,
smart card, or biometric ID.

Password protection policies mitigate against the risk of attackers being able
to compromise an account and use it to launch other attacks on the network.

The credential management policy also needs to alert users to diverse types of
social engineering attacks.

The soft approach to training users can also be backed up by hard policies
defined on the network. System-enforced policies can help to enforce credential
management principles by stipulating requirements for user-selected passwords,
such as length, complexity, filtering dictionary words, history/aging, and so
on. In this context, you should note that the most recent guidance issued by
NIST SP 800-63b deprecates some of the "traditional" elements of password policy:

	• Complexity rules should not be enforced - The user should be allowed to
  choose a password (or other memorized secret) of between 8 and 64 ASCII or
  Unicode characters, including spaces. The only restriction should be to block
  common passwords, such as dictionary words, repetitive strings
  (like 12345678), strings found in breach databases, and strings that repeat
  contextual information, such as username or company name.

	• Aging policies should not be enforced - Users should be able to select if
  and when a password should be changed, though the system should be able to
  force a password change if compromise is detected.

	• Password hints should not be used - A password hint allows account recovery
  by submitting responses to personal information, such as first school or pet
  name.
﻿
One approach to a password hint is to treat it as a secondary password and
submit a random but memorable phrase, rather than an "honest" answer.

While it is easy to use a technical control to stipulate password selection,
blocking password reuse across multiple sites and services is more problematic.

Users must be trained to practice good password management (at the least, not
to reuse work passwords).

One technical solution is to use a password manager. Password manager software
generates a pseudorandom passphrase for each log-on. The passphrase generation
rules can be configured to match the requirements of the authentication system.

The password manager can then submit the credential on behalf of the user. These
account credentials are protected by a master passphrase.

Password managers have been associated with weaknesses and vulnerabilities and
may not be compatible with local authentication systems. Your password policy
might include provisions for allowing or prohibiting use of password managers on
the corporate network and identifying approved and supported vendors.

Another typical network management headache is dealing with users who have
forgotten their password. Manually issuing credentials is time-consuming and
can also be compromised. The new credentials must be transmitted securely to
the user and the administrator should not know what they are.

This is typically achieved using a temporary password, forcing the user to
change it once they have gained access back into the system. The alternative
approach is to allow the user to request and select a new password.

The issue here lies in ensuring that the request is legitimate. There are a few
methods of doing this, but the two most popular are:

	• Challenge questions — Record information that should only be known to the
  user, such as pet names or first school. This functions as a secondary
  password. A well-resourced attacker may be able to discover or guess the
  responses to challenge questions. As noted above, this method is now deprecated.

	• Two-step verification — The user adds a secondary communication channel
  such as an alternate email address or cell/smartphone number. To use the
  password-reset mechanisms, the user must enter a one-time password generated
  by the system and sent to the alternate email or smartphone. Delivery to a
  smartphone could use SMS or a trusted app.


What about Code of Conduct/Ethics? -

A privileged user is one who is given rights to administer a resource. There
might be different levels of privilege, ranging from responsibility for managing
a data set, through departmental IT services administrators, and up to
company-wide service administrators.

A role such as digital forensics investigator also involves privileged access to
confidential and private personal data. An explicit code of conduct and
expectation of ethical behavior for these employees and contractors may be set
out in the contract terms or in a separate privileged user agreement (PUA). A
code of conduct will include things like:

	• Only use privileges to perform authorized job functions

	• Protect the confidentiality and integrity of personal account credentials,
  plus any shared accounts that the privileged user has access to

	• Be aware of and in compliance with any legal and regulatory issues that
  affect data processing, especially as regards PII, SPI, and HPI

	• Respect the privacy of other network users


Acceptable Use Policy (AUP) -

An acceptable use policy (or fair use policy) sets out what someone is allowed
to use a particular service or resource for. Such a policy might be used in
different contexts. For example, an acceptable use policy could be enforced by a
business to govern how employees use equipment and services (such as telephone
or Internet access) provided to them at work. Another example might be an ISP
enforcing a fair use policy governing usage of its Internet access services.

Enforcing an acceptable use policy is important to protect the organization from
the security and legal implications of employees (or customers) misusing its
equipment. Typically, the policy will forbid the use of equipment to defraud,
defame, or to obtain illegal material. It is also likely to prohibit the
installation of unauthorized hardware or software and to explicitly forbid actual
or attempted intrusion (snooping). An organization's acceptable use policy may
forbid use of Internet tools outside of work-related duties or restrict such use
to break times.

Specific corporate acceptable use policies are likely to specify appropriate use
of Internet/web access and use of personally owned devices in the workplace.


What are Data Ownership Policies and Roles? -

Data governance is a complex discipline and in a large business it will require
support from multiple organization roles. A company with formal data ownership
policies will define the following roles:

	• Data owner — A senior (executive) role with ultimate responsibility for
  maintaining the confidentiality, integrity, and availability of the information
  asset. The owner is responsible for labeling the asset (such as determining who
  should have access and determining the asset's criticality and sensitivity) and
  ensuring that it is protected with appropriate controls (access control, backup,
  retention, and so forth). The owner also typically selects a steward and
  custodian and directs their actions and sets the budget and resource allocation
  for sufficient controls.

	• Data steward — This role is primarily responsible for data quality. This
  involves tasks such as ensuring data is labeled and identified with appropriate
  metadata and that data is collected and stored in a format and with values that
  comply with applicable laws and regulations.

	• Data custodian — This role handles managing the system on which the data
  assets are stored. This includes responsibility for enforcing access control,
  encryption, and backup/recovery measures.

	• Privacy officer — This role is responsible for oversight of any PII/SPI/PHI
  assets managed by the company. The privacy officer ensures that the processing
  and disclosure of private/personal data complies with legal and regulatory
  frameworks, such as purpose limitation/consent, data minimization, data
  sovereignty, and data retention.


NOTE: For most businesses, a major challenge is in preventing the IT department
from becoming the owner of all the data the company processes or preventing IT
administrators from becoming de facto data owners by virtue of their privileged
access to the computer network.


What are Retention Policies? -

A set of policies, procedures, and tools for managing the storage of persistent
data.

Retention Standards -

﻿To meet compliance and e-discovery requirements, organizations may be legally
bound to retain certain types of data for a specified period. This type of
requirement will particularly affect financial data and security log data.

Conversely, storage limitation principles in privacy legislation may prevent
you from retaining personal data for longer than is necessary.


Data Retention Policies and Procedures -

Data retention standards mean that detailed policies must be created to show
when and how to dispose of distinct types of data. It is important to include
legal counsel in your organization's data retention policies, as not meeting
requirements can bring about unwanted liability.

﻿Data retention refers to information that is kept for a defined period because
of a policy requirement.

Data preservation refers to information that is kept for a specific purpose
outside of this general policy. For example, you might preserve logs and
security data collected in response to a security incident where a court case
is expected.

A data retention policy uses backup and archiving tools to achieve its aims. Data
retention needs to be considered in the short and long term:

In the short term, files and records that change frequently might need
retaining for version control. Short term retention is also important in
recovering from security incidents. Short term retention is determined by how
often the youngest media sets are overwritten.

In the long term, data may need to be stored to meet legal requirements or to
follow company policies or industry standards. Any data that must be retained in
a version past the oldest sets should be moved to archive storage.

For these reasons, backups are kept back to certain points in time. As backups
take up a lot of space, and there is never limitless storage capacity, this
introduces the need for storage management routines and techniques to reduce
the amount of data occupying backup storage media while giving adequate coverage
of the required recovery window. The recovery window is determined by the
recovery point objective (RPO), which is determined through business continuity
planning.

A retention policy can either be based on redundancy (the number of copies of
each file that should be retained) or on a recovery window (the number of days
into the past that should be retained). Advanced backup software can prevent
media sets from being overwritten in line with the specified retention policy.


Secure Disposal of Data Policy -
﻿
Once the retention period for data has expired, the data must be disposed of,
typically using some sort of secure erase process. Secure data disposal
procedures are also important when it comes to repurposing or releasing computer
equipment, storage devices, and cloud storage services and sites.
