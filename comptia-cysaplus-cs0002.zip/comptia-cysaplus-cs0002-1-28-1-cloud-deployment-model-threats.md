## Episode Name: cloud deployment model threats


### Objectives:
Familiarize learner with threats and vulnerabilities associated with cloud deployment models such as Public, Private, Community, and Hybrid. 

### Code Snippets:


### External Resources:
