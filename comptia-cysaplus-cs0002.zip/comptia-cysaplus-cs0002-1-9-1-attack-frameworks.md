## Episode Name: attack frameworks


### Objectives:
Equip the learner with the ability to employ attack frameworks like MITRE ATT&CK, Diamond Model of Intrusion Analysis, and Cyber Kill Chain for effective threat modeling

### Code Snippets:


### External Resources:
+ https://www.lockheedmartin.com/en-us/capabilities/cyber/cyber-kill-chain.html
+ https://attack.mitre.org/
+ https://apps.dtic.mil/dtic/tr/fulltext/u2/a586960.pdf
