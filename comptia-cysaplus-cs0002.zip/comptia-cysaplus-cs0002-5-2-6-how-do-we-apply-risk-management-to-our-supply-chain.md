## Episode Name: How do we apply Risk Management to our Supply Chains?


### Objectives:

At the end of this episode, I will be able to:

Identify why it is important to apply risk management to the supply chain of an
organization.

Identify what the concepts of Hardware Source Authenticity and a Trusted Foundry
are, and how they can be used to minimize risk in the supply chain.


### External Resources:

How do we apply Risk Management to our Supply Chains?

Most organizations have to depend on "off-the-shelf" products and retail
services. Such organizations can only gain a limited amount of knowledge or
assurance about the security of information processed by these retailers and
producers. Essentially, they must take the vendor's statement of secure design
and usage, as published in OEM documentation or product white papers, at face
value. The steps taken to mitigate the risks inherent in relying on "black box"
commercial systems can be described as "secure working in an unsecure
environment."

Some organizations have the capability to fully control their supply chains,
however. They are able to establish a trusted computing environment, in which
the operation of every element (hardware, firmware, driver, OS, and application)
is consistent and tamper resistant.


Vendor Due Diligence -

There should be an onboarding process for all new vendors, suppliers, and
partners. As part of onboarding, a due diligence search will obtain confirmation
that the vendor meets minimum standards in the following domains:

	• Properly resourced and implemented cybersecurity risk management program

	• Security assurance and risk management for development and manufacturing
  processes, including removal of any development backdoors or other undocumented
  access channels

	• Product support life cycle, including update and security monitoring processes

	• Security controls for any confidential data that the supplier's systems have
  access to

	• Assistance with incident response and forensics investigations

	• General and historical company information, such as financial and regulatory
  reliability, market approval, historic breaches, and so on
﻿

Hardware Source Authenticity and Trusted Foundry -

For a company processing high-value data assets, it is important to verify every
stage of the supply chain, including the manufacturing of electronics in a foundry.

These organizations must be assured that the electronics running their software
and data processing does not contain backdoors or remote monitoring or control
mechanisms.

The US Department of Defense (DoD) has set up a Trusted Foundry Program,
operated by the Defense Microelectronics Activity (DMEA).

Accredited suppliers (dmea.osd.mil/otherdocs/AccreditedSuppliers.pdf) have
proved themselves capable of operating a secure supply chain, from design
through to manufacture and testing.

In terms of procurement, organizations should ensure hardware source
authenticity by purchasing from reputable suppliers, and not from second-hand or
aftermarket sources, where there is a greater risk of inadvertently obtaining
counterfeited or compromised devices.
