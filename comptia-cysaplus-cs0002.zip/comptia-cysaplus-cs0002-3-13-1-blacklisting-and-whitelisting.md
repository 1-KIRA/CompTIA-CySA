## Episode Name: blacklisting and whitelisting


### Objectives:
differentiate between whitelisting and blacklisting so that you can make a more informed decision when setting access controls in your security solutions.

### Code Snippets:


### External Resources:
