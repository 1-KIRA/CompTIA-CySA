## Episode Name: Technical Controls - The Rest


### Objectives:

At the end of this episode, I will be able to:

Identify what Technical controls are.

Identify what the concept of deidentification of data is, and why we have a need
to apply it to help safeguard privacy and security of various types of
organizational data, such as PII, PHI, and SPI.

Identify what the concepts of data masking and Tokenization are, and why awareness 
of them is important to help deidentify organizational data.

Identify what data rights management (department) technology is, and why we have
a need to apply it to certain types of data, such as intellectual property.


### External Resources:

Technical Controls - The Rest

Large datasets are often shared or sold between organizations and companies,
especially within the healthcare industry. Where these datasets contain PII or
PHI, steps can be taken to remove the personal or identifying information.

NOTE: These processes can also be used internally, so that one group within a
company can receive data for analysis without unnecessary risks to privacy.

Deidentification methods may also be used where personal data is collected to
perform a transaction but does not need to be retained thereafter. This reduces
compliance risk when storing data.

For example, a company uses a customer's credit card number to take payment for
an order. When storing the order details, it only keeps the final 4 digits of
the card as part of the transaction log, rather than the full card number.

There are various mechanisms available to apply this sort of deidentification to
datasets. Typically, they are implemented as part of the database management
system (DBMS) hosting the data. Sensitive fields will be tagged for
deidentification whenever a query or report is run.


Data Masking -

Data masking can mean that all or part of the contents of a field are redacted,
by substituting all character strings with "x" for example. A field might be
partially redacted to preserve metadata for analysis purposes.

For example, in a telephone number, the dialing prefix might be retained, but
the subscriber number redacted. Data masking can also use techniques to preserve
the original format of the field. Data masking is an irreversible
deidentification technique.

﻿
Tokenization -

Tokenization means that all or part of data in a field is replaced with a
randomly generated token. The token is stored with the original value on a token
server or token vault, separate to the production database.

An authorized query or app can retrieve the original value from the vault, if
necessary, so tokenization is a reversible technique. Tokenization is used as a
substitute for encryption, because from a regulatory perspective an encrypted
field is the same value as the original data.


Aggregation/Banding -

﻿Another deidentification technique is to generalize the data, such as
substituting a specific age with a broader age band.

﻿
Reidentification -
﻿
It is important to note that given sufficient contextual information, a data
subject can be reidentified, so great care must be taken when applying
deidentification algorithms for distribution to different sources.

A reidentification attack is one that combines a deidentified dataset with other
data sources, such as public voter records, to discover how secure the
deidentification method used is.

K-anonymous information is data that can be linked to 2 or more individuals.
This means that the data does not unambiguously reidentify a specific individual,
but there is a significant risk of reidentification, given the value of K.

For example, if k=5, any group that can be identified within the dataset
contains at least 5 individuals.


NOTE: NIST have produced an overview of deidentification issues SP 800-188.


What is Digital Rights Management (DRM) & Watermarking? -

Digital rights management (DRM) is a family of technologies designed to mitigate
the risks of customers and clients distributing unauthorized copies of content
they have received. There are both hardware and software approaches to DRM:

	• Authorized players — Content can be locked to a particular type of device,
  such as a games console or a TV from an authorized vendor. The device will use
  a cryptographic key to identify itself as an authenticated playback device.
  Internet access to a licensing server may be required so that the device can
  update its activation status, revoke compromised keys, and check that its
  firmware has not been tampered with.

	• Authorized viewers — A DRM file can also be locked to a particular type of
  software running on a general computing host, such as a customized PDF viewer
  or video player that prevent copying by other applications running on the same
  device. These use the same cryptographic mechanisms as hardware players,
  building a hash value to identify each computer, but protecting the software
  against abuse by other programs installed on the computer can be difficult.


Content protection can also be applied using "social DRM" solutions such as
watermarking.

When the file is provisioned to the customer, the content server embeds a
watermark. This could be a visible watermark using an identifying feature of the
customer, or it could be a digital watermark, also called a forensic watermark,
encoded in the file.

A digital watermark can defeat attempts at removal by cropping pages or images
in the file. If the file is subsequently misused (by posting it to a file
sharing site or reusing commercial photography on a different website for
instance), a search tool can locate it, and the copyright owner can attempt
enforcement action.
