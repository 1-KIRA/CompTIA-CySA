## Episode Name: email analysis


### Objectives:
analyze E-mail attacks and defense tactics, so that you can weed out those malicious messages.

### Code Snippets:


### External Resources:
