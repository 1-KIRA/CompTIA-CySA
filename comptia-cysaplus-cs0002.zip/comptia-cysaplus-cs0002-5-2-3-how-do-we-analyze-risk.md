## Episode Name: How do we Analyze Risk?


### Objectives:

At the end of this episode, I will be able to:

Identify what a Business Impact Analysis (BIA) is.

Identify what the metrics that express system availability are as part of a BIA.

Understand what each of the metrics that express system availability as part of
a BIA represent, and how they are used together to provide the outputs of the
BIA process.


### External Resources:

How do we Analyze Risk?

What is a Business impact analysis (BIA)? -

Business impact analysis (BIA) is the process of assessing what losses might
occur for each threat scenario. Impacts can be categorized in several ways, such
as impacts on life and safety, impacts on finance and reputation, and impacts on
privacy.


Business impact analysis is governed by metrics that express system availability:

	• Maximum tolerable downtime (MTD) is the longest period that a business
	function outage may occur without causing irrecoverable business failure. Each
	business process can have its own MTD.

The MTD sets the upper limit on the amount of recovery time that system and
asset owners have to resume operations.

	• Recovery time objective (RTO) is the period following a disaster that an
	individual IT system may remain offline. This is the amount of time it takes
	to identify that there is a problem and then perform recovery (restore from
	backup or switch in an alternative system, for instance).

	• Work recovery time (WRT) represents the time following systems recovery,
	when there may be added work to reintegrate different systems, test overall
	functionality, and brief system users on any changes or different working
	practices so that the business function is again fully supported.

	• Recovery point objective (RPO) is the amount of data loss that a system can
	sustain, measured in time.


MTD and RPO help to determine which business functions are critical and to
specify appropriate risk countermeasures.

For example, if your RPO is measured in days, then a simple tape backup system
should suffice; if RPO is zero or measured in minutes or seconds, a more
expensive server cluster backup and redundancy solution will be needed.
