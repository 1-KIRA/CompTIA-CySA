## Episode Name: software assessment tools and techniques


### Objectives:
Familiarize the learner with software assessment tools output when used to perform static and dynamic code analysis, reverse engineering, and fuzzing. 

### Code Snippets:


### External Resources:
+ https://samate.nist.gov/index.php/Source_Code_Security_Analyzers.html
