## Episode Name: Controls


### Objectives:

At the end of this episode, I will be able to:

Identify what cybersecurity is.

Identify what a security analyst does and where they work within the organization.

Identify what controls are and why they are important to help manage risk in the
organization.

Identify the three different control categories identified by NIST and used on
the CySA+ exam.

Identify the six different functions that controls can perform.


### External Resources:

Controls

What is Cybersecurity? -

Cybersecurity refers to the protection of personal or organizational information
or information resources from unauthorized access, attacks, theft, or data
damage over computer or electronic systems and networks.

A cybersecurity analyst is a senior position within an organization‘s security
team with direct responsibility for protecting sensitive information and
preventing unauthorized access to electronic data and the systems that process it.

A cybersecurity team may contain junior and senior analyst levels, and an
enterprise may develop specialized roles in different sectors of information
assurance. Senior analysts are likely to report directly to the chief information
security officer (CISO).

Some generic analyst job functions and duties include the following:

	• Implementing and configuring security controls, such as firewalls, Intrusion
  Detection Systems, and other threat management appliances and software

	• Working in a leading role in the computer security incident response team
  (CSIRT) or security operations center (SOC) to manage security incidents

	• Auditing security processes and procedures, performing due diligence on
  third parties, and delivering employee training

	• Performing risk assessments, vulnerability assessments, and penetration tests
  and recommending appropriate security controls or procedures

	• Maintaining up-to-date threat intelligence and awareness and advising on
  legal, compliance, and regulatory issues


What makes an analyst successful? -

Successful analysts require technical knowledge of network and security systems
and programming/software development environments, tools, and procedures.
Analysts must also be good at creative thinking and problem solving and be
able to describe a problem and devise and report solutions to a nontechnical
audience with clarity. Attention to detail and patience are also important
characteristics. Finally, incident response situations can be highly pressured,
so calm decision making is another important attribute.


Where do analysts work? -

In many organizations, cybersecurity analysts are likely to work as part of a
security operations center (SOC). A SOC is a location where security
professionals monitor and protect critical information assets in an organization.

SOCs, despite their differences in size, scope, and responsibility, tend to be
designed with a few key principles in mind. A SOC should be:

	• Supported by organizational policies, giving it the authority it needs to be
  effective

	• Able to balance its size and its presence in the organization, without
  overstepping its bounds

	• Staffed with motivated, skilled professionals and not overstaffed with
  under-qualified personnel

	• Able to incorporate a wide variety of security processes into a single
  operations center; Equipped to perform incident response duties

	• Able to protect the SOC's own systems and infrastructure from attack; Aware
  of the strengths and limitations of each tool it uses

	• Aware of the nuances involved in monitoring to be able to separate the
  signal from the noise

	• Willing to collaborate with other SOCs to share valuable information on
  threat intelligence and mitigation techniques


What are controls? -

Cybersecurity exists within a general process of business risk management. To
mitigate risks arising from cyber threats and attacks, organizations must select
and implement effective security controls.

A security control is something designed to give a particular asset or
information system the properties of confidentiality, integrity, availability,
and nonrepudiation.

As modern cyber threats have become more sophisticated, it is now recognized
that security controls should be selected and deployed in a structured way,
within an overall risk management framework. An important part of this is to
classify controls according to their category and/or type of function.

This classification process assists in selecting a diversity of complementary
controls that can act together to provide layered security or defense in depth.

One means of classifying security controls in the context of an overall risk
management framework is set out in the NIST Special Publication 800-53 Security
and Privacy Controls for Federal Information Systems and Organizations.

This document identifies controls as belonging to one of 18 families, such as
access control (AC), audit and accountability (AA), incident response (IR), or
risk assessment (RA).

The family describes the basic functions of the controls. Similarly, the
ISO 27001 framework identifies 14 control categories, such as information
security policies, asset management, physical security, communications security,
and so on.


In the early versions of 800-53, each family is also assigned to a class, based on
the dominant characteristics of the controls included in that family.

The control categories identified in the CySA+ exam objectives are like those
used by NIST:

	• Technical — The control is implemented as a system (hardware, software, or
  firmware). For example, firewalls, anti-virus software, and OS access control
  models are technical controls. Technical controls may also be described as
  logical controls.

	• Operational — The control is implemented primarily by people rather than
  systems. For example, security guards and training programs are operational
  controls rather than technical controls.

	• Managerial — The control gives oversight of the information system. Examples
  could include risk identification or a tool allowing the evaluation and
  selection of other security controls.


However they are classified, as a category or family, controls can also be
described according to the goal or function they perform:

	• Preventative — The control acts to eliminate or reduce the likelihood that
  an attack can succeed. A preventative control operates before an attack can
  take place. Access control lists (ACL) configured on firewalls and file system
  objects are preventative-type controls. Anti-malware software also acts as a
  preventative control, by blocking processes identified as malicious from
  executing. Directives and standard operating procedures (SOPs) can be thought
  of as administrative versions of preventative controls.

	• Detective — The control may not prevent or deter access, but it will
  identify and record any attempted or successful intrusion. A detective control
  operates during the progress of an attack. Logs provide one of the best
  examples of detective-type controls.

	• Corrective — The control acts to eliminate or reduce the impact of an
  intrusion event. A corrective control is used after an attack. A good example
  is a backup system that can restore data that was damaged during an intrusion.
  Another example is a patch management system that acts to eliminate the
  vulnerability exploited during the attack.


NOTE: As no single security control is likely to be invulnerable, it is helpful
to think of them as delaying or hampering an attacker until the intrusion can be
detected. The efficiency of a control is a measure of how long it can delay an
attack.


While most controls can be classed functionally as preventative, detective, or
corrective, a few other types can be used to define other cases:

	• Physical — Controls such as alarms, gateways, locks, lighting, security
  cameras, and guards that deter and detect access to premises and hardware are
  often classed separately.

	• Deterrent — The control may not physically or logically prevent access, but
  psychologically discourages an attacker from attempting an intrusion. This
  could include signs and warnings of legal penalties against trespass or
  intrusion.

	• Compensating — The control serves as a substitute for a principal control,
  as recommended by a security standard, and affords the same (or better) level
  of protection but uses a different methodology or technology.


Adopting a functional approach to security control selection allows you to
devise a Course of Action (CoA) matrix that maps security controls to known
adversary tools and tactics, matching your cybersecurity defensive capabilities
to the offensive capabilities of potential cyber adversaries.
