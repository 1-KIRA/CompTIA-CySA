## Episode Name: continuous integration and deployment


### Objectives:
explore the concepts of Continuous Integration, Delivery, and Deployment which are apart of the Agile model, to enable quick fix and pivot capabilities which then creates a more intrinsically secure system.

### Code Snippets:


### External Resources:
