## Episode Name: incident response communication


### Objectives:
characterize a communications plan as well as analyze factors contributing to data criticality. 

### Code Snippets:


### External Resources:
+ https://gdpr+info.eu/art-33-gdpr/
+ https://www.cisa.gov/sites/default/files/publications/CISAInsights+Cyber-SecureHighValueAssets_S508C.pdf
