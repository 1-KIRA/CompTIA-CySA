## Episode Name: network access control


### Objectives:
evaluate the use of Network Access Control(NAC) mechanisms to prevent the connection of rouge and possibly malicious devices to your environment.

### Code Snippets:


### External Resources:
