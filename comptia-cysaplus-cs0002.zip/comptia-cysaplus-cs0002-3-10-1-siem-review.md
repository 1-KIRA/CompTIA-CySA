## Episode Name: siem review


### Objectives:
become familiarized with SIEM attributes like the dashboard, widgets, and visualizations, as well as rules/queries and data enrichment.

### Code Snippets:


### External Resources:
