## Episode Name: information sharing and analysis communities


### Objectives:
Introduce learner to the importance of information sharing and analysis communities like healthcare, financial, aviation, government, and critical infrastructure. Explore the importance of their shared security and threat experiences in defending against cyber threats. 

### Code Snippets:


### External Resources:
+ https://h-isac.org/
+ https://www.fsisac.com/
+ https://www.a-isac.com/
+ https://www.cisecurity.org/ms+isac/
+ https://www.cisecurity.org/ei+isac/
+ https://www.cisa.gov/critical-infrastructure-sectors
