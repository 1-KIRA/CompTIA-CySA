## Episode Name: controller systems threats


### Objectives:
explore the common threats that could leveraged against ICS and SCADA type systems to help you secure those sensitive targets.

### Code Snippets:


### External Resources:
+ http://dione.lib.unipi.gr/xmlui/bitstream/handle/unipi/11394/Evangeliou_1508.pdf?sequence=1&isAllowed=y
