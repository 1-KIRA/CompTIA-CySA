## Episode Name: firewall configurations


### Objectives:
review how a firewall is commonly employed as well as examine filtering strategies. 

### Code Snippets:


### External Resources:
+ https://team+cymru.com/community-services/bogon-reference/
