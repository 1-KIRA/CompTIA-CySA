## Episode Name: impact analysis


### Objectives:
define the attributes of impact analysis including types and scope so that you can properly categorize and clarify the damage caused by a security incident.

### Code Snippets:


### External Resources:
