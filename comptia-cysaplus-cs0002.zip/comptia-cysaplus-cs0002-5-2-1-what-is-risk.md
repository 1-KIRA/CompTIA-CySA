## Episode Name: What is Risk?


### Objectives:

At the end of this episode, I will be able to:

Identify what risk is.

Identify what the NIST's Managing Information Security Risk special publication
SP 800-39, four structural components or functions are.

Identify what a System Assessment Process is.


### External Resources:

What is Risk?

The comprehensive process of evaluating, measuring, and mitigating the many
risks that pervade an organization is called enterprise risk management (ERM).


A good starting point for applying a process of risk identification and
assessment is NIST's Managing Information Security Risk special publication
SP 800-39. NIST identifies four structural components or functions:

	• Frame — Establish a strategic risk management framework, supported by
  decision makers at the top tier of the organization. The risk frame sets an
  overall goal for the degree of risk that can be tolerated and demarcates
  responsibilities. The risk frame directs and receives inputs from all other
  processes and should be updated as changes to the business and security
  landscape arise.

	• Assess — Identify and prioritize business processes/workflows. Perform a
  systems assessment to determine which IT assets and procedures support these
  workflows. Identify risks to which information systems and therefore the
  business processes they support are exposed.

	• Respond — Mitigate each risk factor through the deployment of managerial,
  operational, and technical security controls.

	• Monitor — Evaluate the effectiveness of risk response measures and identify
  changes that could affect risk management processes.

** Risk identification takes place within the assess component.

It proceeds by evaluating threats, identifying vulnerabilities, and assessing
he probability (or likelihood) of an event affecting an asset or process.

This can be combined with impact analysis (magnitude) to determine risk.

NOTE: By cataloging and assessing business processes, threats, and
vulnerabilities, you can derive values for probability and magnitude, through
quantitative or qualitative assessment methods.


What is a Systems Assessment Process? -

In order to design a risk assessment process, you must know what you want to
make secure through a process of systems assessment. It is crucial for an
organization to perform the identification of critical systems. This means
compiling an inventory of its business processes and, for each process, the
tangible and intangible assets and resources that support them. These could
include the following:

	• People — Employees, visitors, and suppliers

	• Tangible assets — Buildings, furniture, equipment and machinery (plant),
  ICT equipment, electronic data files, and paper documents.

  • Intangible assets—Ideas, commercial reputation, brand, and so on

	• Procedures — Supply chains, critical procedures, standard operating
  procedures, and workflows


Within the full set of processes and assets, those that support mission
essential functions (MEF) should be prioritized.

A MEF is one that cannot be deferred. This means that the organization must be
able to perform the function as close to continually as possible, and if there
is any service disruption, the mission essential functions must be restored
first.

Functions that act as support for the business or an MEF but are not critical
in themselves are referred to as primary business functions (PBF).
