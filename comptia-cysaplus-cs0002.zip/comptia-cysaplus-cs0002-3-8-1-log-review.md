## Episode Name: log review


### Objectives:
identify the common systems/applications and their log files that a cybersecurity analyst needs to be familiar with when investigating a security event.

### Code Snippets:


### External Resources:
+ https://zecure.me/
+ https://demo.shadowd.zecure.org/login
