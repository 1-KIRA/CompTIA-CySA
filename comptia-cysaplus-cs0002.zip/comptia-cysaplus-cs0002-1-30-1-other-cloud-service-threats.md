## Episode Name: other cloud service threats


### Objectives:
Familiarize learner with threats and vulnerabilities associated with other cloud-based services such as FaaS, IaC, Insecure API, Key Management issues, and unprotected storage.

### Code Snippets:


### External Resources:
