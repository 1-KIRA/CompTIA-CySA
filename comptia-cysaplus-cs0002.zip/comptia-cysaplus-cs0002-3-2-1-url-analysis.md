## Episode Name: url analysis


### Objectives:
Analyze the components of a URL and assess techniques used in url-based attacks.

### Code Snippets:


### External Resources:
