## Episode Name: certificate management


### Objectives:
Explain how certificates are useful in securing communications and authentication. Describe the benefits of certificates in specific environments

### Code Snippets:


### External Resources:
