## Episode Name: cvss metrics


### Objectives:
Expose learner to CVSS components such as Base Metrics, Temporal Metrics, and Environmental Metrics as well as their associated Exploitability Metrics and Score. 

### Code Snippets:


### External Resources:
+ https://www.first.org/cvss/specification-document
