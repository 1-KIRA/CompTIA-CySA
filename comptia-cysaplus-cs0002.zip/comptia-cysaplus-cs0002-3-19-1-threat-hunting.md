## Episode Name: threat hunting


### Objectives:
ascertain the usefulness of Threat Hunting toward that end; identifying the concepts, methods, and benefits that threat hunting entails. 

### Code Snippets:


### External Resources:
