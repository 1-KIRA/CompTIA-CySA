## Episode Name: asset tagging and change management


### Objectives:
Explore security solutions for infrastructure management. Explain how asset tagging allows you to track assets and discover lost items or shadow IT. Use change management to track updates and security controls.

### Code Snippets:


### External Resources:
+ https://www.seton.com/asset+management/asset-tags.html
+ https://www.reftab.com
