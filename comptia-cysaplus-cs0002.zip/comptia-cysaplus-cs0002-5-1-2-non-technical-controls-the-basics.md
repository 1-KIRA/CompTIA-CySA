## Episode Name: Non-Technical Controls - The Basics


### Objectives:

At the end of this episode, I will be able to:

Identify what non-technical controls are.

Identify what data governance is, and why we have a need to apply it in
the organization.

Identify what the concepts of classification and confidentiality are, and why we
have a need to apply them to our data.

Identify what the concept of purpose limitation as it applies to data collection
is, and why we have a need to use it to help govern and secure our data.

Identify what the concepts of data minimization and data sovereignty are, and
why we have a need to apply them to our data.


### External Resources:

Non-Technical Controls - The Basics

Data governance is the process of managing information over its life cycle from
creation to destruction. At each stage of the life cycle, data policies, standard
procedures, and technical security controls are important in reducing the risk of
data loss or theft. Data governance is an essential competency for all
organizations. A data life cycle involves the following processes:

	• Classification of data as it is created or collected
	• Security of data as it is stored, including access controls and
  backup/recovery procedures
	• Management of data as it is distributed to data consumers
	• Retention or destruction of data


Classification and Confidentiality -

Data classification and typing schemas tag data assets so that they can be
identified and monitored more easily. Data classification is a tag or label that
shows how confidential it is. Data confidentiality can be divided into several
levels, following military usage:

	• Unclassified (public) — There are no restrictions on viewing the data

	• Classified (private/internal use only/official use only) — Viewing is
  restricted to authorized persons within the owner organization or to third
  parties under a non-disclosure agreement (NDA)

	• Confidential (or restricted) — The information is highly sensitive, for
  viewing only by approved persons within the organization (and possibly by
  trusted third parties under NDA)

	• Secret — The information is too valuable to allow any risk of its capture.
  Viewing is severely restricted

	• Top-Secret — this is the highest level of classification
﻿

Organizations may well use a simpler classification scheme, such as using just
three levels—public, private/internal, and restricted.

﻿The requirements to protect information will differ between jurisdictions, so
you must examine the applicable regulatory requirements to ensure the
classification scheme takes this into account. Classification might be processed
manually or there may be an automated software means of attaching a sensitivity
label to new documents and database records/fields.

Information may change in sensitivity, typically becoming less sensitive over
time. A document may be downgraded to a lower security level or eventually
declassified. In this circumstance, there needs to be a clear process of
authorization and notification, so that confidentiality is not breached.


Data Types and Privacy -

Data can also be tagged as a particular type. The data type is important in
terms of evaluating privacy as well as security requirements.

For example, personal data can be classified into standard types, including
personally identifiable information (PII), sensitive personal information (SPI),
personal health information (PHI), and financial information.

Within these broad categories, you might identify many specific types.

Data governance might require additional type labels or tags.

For example, you might want to tag intellectual property (IP), accounts,
fulfilment/operational, and security monitoring data types.


Data Formats and States -
﻿
Classification schemes might also be needed for different data formats, such as
structured versus unstructured.

Data state refers to the location of data within a processing system, with
classifications such as data at rest, data in motion, and data in use.


Purpose Limitation -

Privacy regulations such as GDPR stipulate that data can only be collected for
a defined purpose, for which the data subject must give explicit consent.

Data collected under that consent statement cannot then be used for any other
purpose.

For example, if you collect an email address for use as an account ID, you may
not send marketing messages to that email address without obtaining separate
consent for that discrete purpose.

Purpose limitation will also restrict your ability to transfer data to third
parties. Tracking consent statements and keeping data usage in compliance with
the consent granted is a significant management task.

In organizations that process large amounts of personal data, technical tools
that perform tagging and cross-referencing of personal data records will be
required.


Data Minimization -

Data minimization is the principle that data should only be processed and stored
if that is necessary to perform the purpose for which it is collected.

In order to prove compliance with the principle of data minimization, each
process that uses personal data should be documented.

The workflow can supply evidence of why processing and storage of a particular
field or data point is required.

Data minimization affects the data retention policy. It is necessary to track
how long a data point has been stored for since it was collected and whether
continued retention supports a legitimate processing function.

NOTE: Another impact is on test environments, where the minimization principle
forbids the use of real data records.

NOTE: The principle of minimization also includes the principle of sufficiency
or adequacy. This means that you should collect the data required for the stated
purpose in a single transaction to which the data subject can give clear
consent. Collecting additional data later would not be compliant with this
principle.


Data Sovereignty -

Data sovereignty refers to a jurisdiction preventing or restricting processing
and storage from taking place on systems do not physically reside within that
jurisdiction.

Data sovereignty may demand certain concessions on your part, such as using
location-specific storage facilities in a cloud service.

For example, GDPR protections are extended to any EU citizen while they are
within EU or EEA (European Economic Area) borders. Data subjects can consent to
allow a transfer but there must be a meaningful option for them to refuse consent.

If the transfer destination jurisdiction does not provide adequate privacy
regulations (to a level comparable to GDPR), then contractual safeguards must
be given to extend GDPR rights to the data subject.

In the US, companies can self-certify that the protections they offer are
adequate under the Privacy Shield scheme (privacyshield.gov/US-Businesses).
