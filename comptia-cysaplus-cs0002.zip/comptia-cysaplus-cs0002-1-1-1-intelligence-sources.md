## Episode Name: intelligence sources


### Objectives:
Become familiarized with Open-Source Intelligence(OSINT) and Closed-Source Intelligence, the difference between the two and how they are collected. Identify attributes of good intelligence sources.

### Code Snippets:


### External Resources:
