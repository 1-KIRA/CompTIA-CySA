## Episode Name: file system permissions


### Objectives:
employ tools in Windows and Linux systems to determine what permissions are set and how to appropriately change them. 

### Code Snippets:


### External Resources:
